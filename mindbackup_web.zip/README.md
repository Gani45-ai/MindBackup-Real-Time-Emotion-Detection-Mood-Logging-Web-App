MindBackup — Web App (Flask) — Live emotion capture + emoji UI
------------------------------------------------------------

How it works (quick):
- Open the app in browser. The page requests camera permission.
- The browser captures a snapshot every 5 seconds and sends it to the server (/analyze).
- Server analyzes the image using DeepFace, saves the image and records a DB entry.
- The page updates the gallery and switches into a 'mood mode' (full-page color/emoji) depending on the detected emotion.
- There's a stats panel that shows counts for the last minute, day, week, month.

Run locally (macOS/Linux/Windows):
1. Create & activate a Python venv
   python3 -m venv venv
   source venv/bin/activate   # or .\venv\Scripts\activate on Windows
2. Install requirements
   pip install -r requirements.txt
3. Start the server
   python app.py
4. Open browser at http://127.0.0.1:5000

Files included:
- app.py             (Flask server)
- db.py              (SQLite helper)
- templates/index.html
- static/js/main.js
- static/css/style.css
- memories/          (saved images)
- requirements.txt
- README.md

Notes:
- This uses DeepFace for emotion detection which requires TensorFlow. On macOS, prefer the tensorflow-macos + tensorflow-metal pairing if you have Apple Silicon.
- If DeepFace loading is slow the first time, be patient — model weights download and initialization can take 20-60 seconds.
- All data stored locally in the 'memories' folder and 'mindbackup.db' SQLite file.
